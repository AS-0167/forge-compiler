fn int my_fn(int x, float y) {
    // Functio  
    int my_int = x+y*8-3*(3/2);
    float my_float = x+y;
    string my_str = "hmm";
    bool my_bool=x==453 ;
    return x;
}

/* This is a comment*/

fn int main() {
    int x = my_fn(1,2);
    char c = 'a';
    float y = .4e-4;
    return x;
}
